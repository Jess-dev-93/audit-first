"use client";

import { getProfileFallbacks } from "../lib/templateUtils";
import { getScoreStyles } from "../lib/scoreColors";
import type { UserProfile } from "../lib/profileStorage";
import type { TechStack } from "../lib/techStack";

type IssueSeverity = "high" | "medium" | "low" | "review";

type SitePageResult = {
  url: string;
  pageType: string;
  status: string;
  httpStatus?: number | null;
  error?: string | null;
  title: string;
  metaDescription: string;
  h1Count: number;
  canonicalPresent: boolean;
  robotsNoindex: boolean;
  langPresent: boolean;
  viewportPresent: boolean;
  imageCount: number;
  imagesMissingAlt: number;
  structuredDataPresent: boolean;
  structuredDataTypes: string[];
  ogPresent: boolean;
  internalLinks: number;
  externalLinks: number;
  formCount: number;
  phoneLinks: string[];
  emailLinks: string[];
  ctaLabels: string[];
  newsletterPresent: boolean;
  accountEntryPoint: boolean;
};

type IssueSummaryItem = {
  key: string;
  label: string;
  count: number;
  percentage: number;
  severity: IssueSeverity;
  interpretation: string;
};

type LighthouseFinding = {
  id: string;
  categoryLabel: string;
  title: string;
  priority: "high" | "medium" | "low";
  displayValue?: string | null;
  savingsMs?: number | null;
  savingsBytes?: number | null;
  affectedItemCount?: number;
};

type DeepResult = {
  url: string;
  pageType: string;
  pageTitle?: string | null;
  error?: string | null;
  scores: {
    mobile: {
      performance: number;
      seo: number;
      accessibility: number;
      bestPractices: number;
    };
    desktop?: {
      performance: number;
      seo: number;
      accessibility: number;
      bestPractices: number;
    } | null;
    evidence?: {
      mobile?: { topFindings?: LighthouseFinding[] } | null;
      desktop?: { topFindings?: LighthouseFinding[] } | null;
    };
  } | null;
};

type RecommendedEvent = {
  event: string;
  trigger: string;
  purpose: string;
};

type JourneySummary = {
  pageTypes: string[];
  formCount: number;
  pagesWithForms: number;
  pagesWithPhoneLinks: number;
  pagesWithEmailLinks: number;
  newsletterPresent: boolean;
  accountEntryPoint: boolean;
  ctaLabels: string[];
  observations: string[];
  opportunities: string[];
  analyticsDetected: string[];
  recommendedEvents: RecommendedEvent[];
};

type SiteReport = {
  executiveSummary: string;
  strengths: string[];
  keyIssues: string[];
  businessImpact: string[];
  analyticsStatement: string;
  journeyObservations: string[];
  journeyOpportunities: string[];
  recommendations: string[];
  roadmap: {
    immediate: string[];
    nearTerm: string[];
    ongoing: string[];
  };
  scopeNotes: string[];
};

export type FullSiteAuditResult = {
  success: boolean;
  generatedAt?: string;
  discovery?: {
    discoveredPages: string[];
    recommendedPages: string[];
    discoveredCount: number;
    reviewedPageCount?: number;
    discoveryLimited?: boolean;
    source: string;
    url: string;
    origin: string;
  };
  lightweightResults?: SitePageResult[];
  issueSummary?: IssueSummaryItem[];
  selectedDeepAuditPages?: string[];
  deepResults?: DeepResult[];
  deepSummary?: {
    attemptedCount: number;
    count: number;
    failedCount: number;
    averageMobilePerformance: number | null;
    homepageDesktopPerformance: number | null;
    averageAccessibility: number | null;
    averageBestPractices: number | null;
    averageSeo: number | null;
  };
  techStack?: TechStack;
  journeySummary?: JourneySummary;
  siteReport?: SiteReport;
  error?: string;
};

type Props = {
  result: FullSiteAuditResult;
  profile?: Partial<UserProfile>;
};

type ClientPriority = {
  title: string;
  finding: string;
  impact: string;
  action: string;
  tone: "urgent" | "important" | "measure";
};

type ReportFinding = LighthouseFinding & {
  pageType: string;
  url: string;
  sourceOrder: number;
};

const SERVICES = [
  "Website development, improvements and ongoing technical support",
  "Performance, accessibility and technical SEO improvements",
  "Customer-journey and conversion-pathway improvements",
  "Analytics, conversion tracking and reporting",
  "CMS, forms, CRM and third-party integrations",
  "Ongoing testing and optimisation based on real evidence",
];

function list<T>(value: T[] | undefined | null): T[] {
  return Array.isArray(value) ? value : [];
}

function unique(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean)));
}

function escapeHtml(value: unknown) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function hostname(value: string) {
  try {
    return new URL(value).hostname.replace(/^www\./, "");
  } catch {
    return value;
  }
}

function pagePath(value: string) {
  try {
    const url = new URL(value);
    return url.pathname === "/" ? "/" : url.pathname.replace(/\/$/, "");
  } catch {
    return value;
  }
}

function clientName(result: FullSiteAuditResult) {
  const homepage = list(result.lightweightResults).find(
    (page) => page.pageType === "Homepage",
  );
  const title = homepage?.title?.split(/\s+[|–—]\s+|\s+-\s+/)[0]?.trim();

  if (title && title.length <= 80) return title;

  const host = result.discovery?.origin || result.discovery?.url || "";
  return hostname(host)
    .split(".")[0]
    .split(/[-_]/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function humanList(values: string[]) {
  if (values.length === 0) return "";
  if (values.length === 1) return values[0];
  return `${values.slice(0, -1).join(", ")} and ${values.at(-1)}`;
}

function scoreHex(score: number | null | undefined) {
  if (typeof score !== "number") return "#64748b";
  return getScoreStyles(score).hex;
}

function scoreMeaning(
  kind: "performance" | "seo" | "accessibility" | "bestPractices",
  score: number | null | undefined,
) {
  if (typeof score !== "number") return "Not tested";

  if (kind === "performance") {
    if (score < 50) return "Priority improvement area";
    if (score < 90) return "Needs improvement";
    return "Strong result";
  }

  if (kind === "seo") {
    if (score >= 90) return "Strong search foundation";
    if (score >= 70) return "Good foundation with gaps";
    return "Search foundations need work";
  }

  if (kind === "accessibility") {
    if (score >= 90) return "Strong automated result";
    if (score >= 70) return "Good foundation; issues remain";
    return "Accessibility needs attention";
  }

  if (score >= 90) return "Strong technical foundation";
  if (score >= 70) return "Good foundation with gaps";
  return "Technical checks need attention";
}

function friendlyFindingTitle(finding: LighthouseFinding) {
  const value = `${finding.id} ${finding.title}`.toLowerCase();

  if (
    value.includes("unused-javascript") ||
    value.includes("unused javascript")
  ) {
    return "Remove website code that visitors do not need";
  }
  if (
    value.includes("total-blocking-time") ||
    value.includes("total blocking time")
  ) {
    return "Reduce the time the page remains unresponsive";
  }
  if (
    value.includes("largest-contentful-paint") ||
    value.includes("largest contentful paint")
  ) {
    return "Show the main page content sooner";
  }
  if (
    value.includes("first-contentful-paint") ||
    value.includes("first contentful paint")
  ) {
    return "Show the first page content sooner";
  }
  if (value.includes("speed-index") || value.includes("speed index")) {
    return "Make the page feel visually complete sooner";
  }
  if (value.includes("alt") && value.includes("image")) {
    return "Add descriptions to important images";
  }
  if (value.includes("user-scalable") || value.includes("maximum-scale")) {
    return "Allow visitors to zoom properly on mobile";
  }
  if (value.includes("contrast"))
    return "Improve text and background colour contrast";
  if (value.includes("discernible name") || value.includes("link-name")) {
    return "Give every link a clear readable label";
  }
  if (value.includes("tap target"))
    return "Make buttons and links easier to tap";
  if (value.includes("heading") && value.includes("order")) {
    return "Correct the page heading order";
  }
  if (value.includes("render-blocking"))
    return "Load important page content first";
  if (value.includes("unused css")) return "Remove unused styling code";
  if (value.includes("responsive image"))
    return "Serve images at the right size";
  if (value.includes("modern image")) return "Use more efficient image formats";

  return finding.title;
}

function findingImpact(finding: LighthouseFinding) {
  const category = finding.categoryLabel.toLowerCase();

  if (category.includes("performance")) {
    return "This can make the page feel slow or unresponsive, especially on mobile.";
  }
  if (category.includes("accessibility")) {
    return "This can make the page harder to use with zoom, screen readers, keyboards or touch controls.";
  }
  if (category.includes("seo")) {
    return "This can reduce how clearly search engines understand and present the page.";
  }

  return "This should be reviewed to improve reliability, usability and visitor trust.";
}

function buildFindingEvidence(finding: LighthouseFinding) {
  const evidence: string[] = [];

  if (finding.displayValue) evidence.push(finding.displayValue);

  if (
    typeof finding.savingsMs === "number" &&
    finding.savingsMs > 0 &&
    !/\b(?:ms|milliseconds?|seconds?|sec|s)\b/i.test(finding.displayValue || "")
  ) {
    evidence.push(`${Math.round(finding.savingsMs)} ms estimated improvement`);
  }

  if (
    typeof finding.savingsBytes === "number" &&
    finding.savingsBytes > 0 &&
    !/\b(?:KiB|MiB|KB|MB|bytes?)\b/i.test(finding.displayValue || "")
  ) {
    evidence.push(
      `${Math.round(finding.savingsBytes / 1024)} KiB potential reduction`,
    );
  }

  if (
    typeof finding.affectedItemCount === "number" &&
    finding.affectedItemCount > 0
  ) {
    evidence.push(
      `${finding.affectedItemCount} affected item${finding.affectedItemCount === 1 ? "" : "s"}`,
    );
  }

  return unique(evidence).join("; ");
}

function selectTechnicalFindings(
  deepResults: DeepResult[],
  limit = 10,
): ReportFinding[] {
  const weight = { high: 3, medium: 2, low: 1 };
  const candidates = deepResults
    .flatMap((item) =>
      list(item.scores?.evidence?.mobile?.topFindings).map((finding) => ({
        ...finding,
        pageType: item.pageType,
        url: item.url,
        sourceOrder: 0,
      })),
    )
    .map((finding, index) => ({ ...finding, sourceOrder: index }))
    .sort((a, b) => {
      const priority = weight[b.priority] - weight[a.priority];
      if (priority !== 0) return priority;
      const time = (b.savingsMs || 0) - (a.savingsMs || 0);
      if (time !== 0) return time;
      const bytes = (b.savingsBytes || 0) - (a.savingsBytes || 0);
      return bytes !== 0 ? bytes : a.sourceOrder - b.sourceOrder;
    });

  const selected: ReportFinding[] = [];
  const seen = new Set<string>();
  const auditCounts = new Map<string, number>();

  function add(finding?: ReportFinding, enforceAuditLimit = true) {
    if (!finding || selected.length >= limit) return false;

    const key = `${finding.url}:${finding.id}`;
    const currentCount = auditCounts.get(finding.id) || 0;

    if (seen.has(key) || (enforceAuditLimit && currentCount >= 2)) return false;

    seen.add(key);
    auditCounts.set(finding.id, currentCount + 1);
    selected.push(finding);
    return true;
  }

  ["Performance", "Accessibility", "SEO", "Best Practices"].forEach(
    (category) => {
      add(candidates.find((finding) => finding.categoryLabel === category));
    },
  );

  deepResults.forEach((page) => {
    add(
      candidates.find(
        (finding) =>
          finding.url === page.url && !seen.has(`${finding.url}:${finding.id}`),
      ),
    );
  });

  candidates.forEach((finding) => add(finding));
  if (selected.length < limit)
    candidates.forEach((finding) => add(finding, false));

  return selected.slice(0, limit);
}

function buildClientPriorities(
  result: FullSiteAuditResult,
  successfulPages: number,
): ClientPriority[] {
  const summary = result.deepSummary;
  const pages = list(result.lightweightResults).filter(
    (page) => page.status === "ok",
  );
  const journey = result.journeySummary;
  const propertyListings = pages.filter((page) =>
    /property listing/i.test(page.pageType),
  ).length;
  const propertyDetails = pages.filter((page) =>
    /property detail/i.test(page.pageType),
  ).length;
  const testedPages = summary?.count ?? 0;
  const performance = summary?.averageMobilePerformance;
  const accessibility = summary?.averageAccessibility;
  const additionalPathways = unique([
    (journey?.pagesWithPhoneLinks ?? 0) > 0 ? "telephone links" : "",
    (journey?.pagesWithEmailLinks ?? 0) > 0 ? "email links" : "",
    journey?.newsletterPresent ? "a newsletter sign-up" : "",
    journey?.accountEntryPoint ? "an account entry point" : "",
  ]);

  const formFinding =
  (journey?.formCount ?? 0) > 0
    ? `The reviewed sample included several form-based actions${
        additionalPathways.length
          ? `, alongside ${humanList(additionalPathways)}`
          : ""
      }. Their purpose, completion behaviour and follow-up processes should be confirmed manually.`
    : additionalPathways.length
      ? `The reviewed pages provide ${humanList(additionalPathways)}, but no public enquiry form was detected.`
      : "No clear public enquiry pathway was detected in the reviewed sample.";

  const propertyFinding =
    propertyListings + propertyDetails > 0
      ? `The reviewed sample included ${propertyListings} property-listing page${propertyListings === 1 ? "" : "s"} and ${propertyDetails} individual property page${propertyDetails === 1 ? "" : "s"}.`
      : "The website contains multiple services and content pathways for visitors to explore.";

  const propertyTitle =
    propertyListings + propertyDetails > 0
      ? "Make properties easier to explore and compare"
      : "Make services easier to explore and compare";

  const propertyAction =
    propertyListings + propertyDetails > 0
      ? "Present price, availability, location, status, key features and the next action consistently across property search and detail pages."
      : "Use consistent page structures, benefit-led summaries and relevant next actions across priority services.";

  return [
    {
      title: "Make the website's value clear sooner",
      finding: `The ${successfulPages}-page reviewed sample supports several audiences, services, property content and enquiry pathways.`,
      impact:
        "When a website serves different audiences, a strong visual hierarchy helps each visitor quickly recognise the information and action most relevant to them.",
      action:
        "Refine the homepage message, content order and calls to action so developers, buyers, investors, agents and partners can enter the right pathway sooner.",
      tone: "important",
    },
    {
      title: propertyTitle,
      finding: propertyFinding,
      impact:
        "Consistent, easy-to-scan information helps visitors assess options confidently without working through long or uneven page content.",
      action: propertyAction,
      tone: "important",
    },
    {
      title: "Create a smoother path from interest to enquiry",
      finding: formFinding,
      impact:
        "Clear, uninterrupted forms and relevant calls to action make it easier for an interested visitor to complete the next step.",
      action:
        "Review the mobile enquiry experience, reduce visual interruptions, explain any qualification questions and confirm success and follow-up expectations clearly.",
      tone: "measure",
    },
    {
      title: "Strengthen performance, accessibility and insight",
      finding: `${testedPages} completed key-page tests averaged ${performance ?? "N/A"}/100 for mobile speed and ${accessibility ?? "N/A"}/100 for accessibility. Public tracking tools were also detected.`,
      impact:
        "A faster, more inclusive experience can support engagement, while reliable measurement shows which improvements and campaigns create meaningful interest.",
      action:
        "Prioritise the shared templates behind the measured issues, then confirm property views, enquiry starts, completed enquiries, calls and emails are recorded accurately.",
      tone:
        typeof performance === "number" && performance < 50
          ? "urgent"
          : "important",
    },
  ];
}

function buildClientSummary(
  result: FullSiteAuditResult,
  successfulPages: number,
) {
  const summary = result.deepSummary;
  const performance = summary?.averageMobilePerformance;
  const seo = summary?.averageSeo;
  const tested = summary?.count ?? 0;

  const speedSentence =
    typeof performance === "number"
      ? `The clearest improvement opportunity is mobile performance: ${tested} important pages averaged ${performance}/100.`
      : "Mobile performance should be tested again before priorities are confirmed.";

  const searchSentence =
    typeof seo === "number" && seo >= 90
      ? `Search foundations were comparatively strong, averaging ${seo}/100 across the tested pages.`
      : "Search foundations are present, with page-level gaps that should be corrected on priority templates.";

  return `${clientName(result)} already has a substantial public website supporting services, property discovery, useful content and enquiries. This review examined a ${successfulPages}-page public sample to identify where that existing foundation could deliver even more value. ${speedSentence} ${searchSentence} The opportunity is to make key journeys clearer and easier to use, then confirm which website and marketing activity creates meaningful enquiries.`;
}

function buildOverallPicture(result: FullSiteAuditResult) {
  const journey = result.journeySummary;
  const summary = result.deepSummary;
  const availablePathways = unique([
    (journey?.formCount ?? 0) > 0 ? "form-based actions" : "",
    (journey?.pagesWithPhoneLinks ?? 0) > 0 ? "telephone links" : "",
    (journey?.pagesWithEmailLinks ?? 0) > 0 ? "email links" : "",
    journey?.newsletterPresent ? "newsletter sign-up" : "",
    journey?.accountEntryPoint ? "account features" : "",
  ]);
  const bullets = [
    availablePathways.length
      ? `The website already gives visitors access to ${humanList(availablePathways)}.`
      : "The website already provides public content that can support visitor research and decision-making.",
  ];

  if (typeof summary?.averageSeo === "number") {
    bullets.push(
      summary.averageSeo >= 90
        ? "Automated search-readiness results provide a strong foundation for focused improvement."
        : "The search-readiness results show a foundation that can be strengthened across priority pages.",
    );
  }

  if (typeof summary?.averageMobilePerformance === "number") {
    bullets.push(
      summary.averageMobilePerformance < 50
        ? "The clearest measured opportunity is mobile speed, supported by clearer journeys, inclusive usability and reliable enquiry measurement."
        : "The next opportunity is to refine key journeys, inclusive usability and reliable enquiry measurement.",
    );
  }

  return bullets;
}

function analyticsSummary(result: FullSiteAuditResult) {
  const tech = result.techStack;
  const signals = unique([
    ...list(tech?.analytics),
    ...list(tech?.tagManagers),
    ...list(tech?.marketing),
  ]);

  if (signals.length === 0) {
    return "No clearly identifiable analytics or tag-management signal was found in the public page code. This does not prove tracking is absent, because it may load after consent or through server-side systems.";
  }

  return `Public signals for ${humanList(signals)} were found. This confirms that tools are present, but it does not confirm that consent, enquiry tracking, reporting or CRM follow-up are configured correctly.`;
}

function renderList(items: string[], className = "") {
  if (!items.length) return "";
  return `<ul class="${className}">${items
    .map((item) => `<li>${escapeHtml(item)}</li>`)
    .join("")}</ul>`;
}

export function buildReportHtml(
  result: FullSiteAuditResult,
  profile?: Partial<UserProfile>,
) {
  const profileValues = getProfileFallbacks(profile);
  const report = result.siteReport;
  const discovery = result.discovery;
  const pages = list(result.lightweightResults);
  const deepResults = list(result.deepResults);
  const tech = result.techStack;
  const summary = result.deepSummary;
  const company = clientName(result);
  const displayUrl = discovery?.origin || discovery?.url || "";
  const successfulPages = pages.filter((page) => page.status === "ok").length;
  const priorities = buildClientPriorities(result, successfulPages);
  const clientSummary = buildClientSummary(result, successfulPages);
  const technicalFindings = selectTechnicalFindings(deepResults, 10);
  const discoveryCount = discovery?.discoveredCount ?? pages.length;
  const discoveryDisplay = discovery?.discoveryLimited
    ? `${discoveryCount}+`
    : String(discoveryCount);
  const reportDate = new Date(
    result.generatedAt || Date.now(),
  ).toLocaleDateString("en-AU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const contactLinks = [
    profileValues.yourWebsite,
    profileValues.yourLinkedIn,
  ].filter(Boolean);

  const scoreCards = [
    [
      "Mobile speed",
      summary?.averageMobilePerformance,
      scoreMeaning("performance", summary?.averageMobilePerformance),
    ],
    [
      "Search readiness",
      summary?.averageSeo,
      scoreMeaning("seo", summary?.averageSeo),
    ],
    [
      "Accessibility",
      summary?.averageAccessibility,
      scoreMeaning("accessibility", summary?.averageAccessibility),
    ],
    [
      "Best practices",
      summary?.averageBestPractices,
      scoreMeaning("bestPractices", summary?.averageBestPractices),
    ],
    [
      "Homepage desktop speed",
      summary?.homepageDesktopPerformance,
      scoreMeaning("performance", summary?.homepageDesktopPerformance),
    ],
  ];

  const techGroups = [
    ["Website platform", tech?.cms || "Not identified"],
    ["Page-building system", tech?.pageBuilder || "Not identified"],
    ["Hosting / delivery", tech?.hosting || "Not identified"],
    [
      "Analytics",
      list(tech?.analytics).join(", ") || "No direct property identified",
    ],
    [
      "Tag management",
      list(tech?.tagManagers).join(", ") || "No signal identified",
    ],
    [
      "Marketing tools",
      list(tech?.marketing).join(", ") || "No signal identified",
    ],
    ["Forms", list(tech?.forms).join(", ") || "No named provider identified"],
    [
      "Consent platform",
      list(tech?.consent).join(", ") || "No named platform identified",
    ],
    [
      "Other connections",
      list(tech?.integrations).join(", ") || "No named connection identified",
    ],
  ];

  const priorityCards = priorities
    .map(
      (priority, index) => `
    <article class="priority-card priority-${escapeHtml(priority.tone)}">
      <div class="priority-number">${index + 1}</div>
      <div>
        <h3>${escapeHtml(priority.title)}</h3>
        <p><strong>What we found:</strong> ${escapeHtml(priority.finding)}</p>
        <p><strong>Why it matters:</strong> ${escapeHtml(priority.impact)}</p>
        <p><strong>What to do:</strong> ${escapeHtml(priority.action)}</p>
      </div>
    </article>`,
    )
    .join("");

  const deepRows = deepResults
    .map((item) => {
      if (!item.scores?.mobile) {
        return `<tr><td><strong>${escapeHtml(item.pageType)}</strong><br><span class="mono">${escapeHtml(pagePath(item.url))}</span></td><td colspan="5">Test unavailable: ${escapeHtml(item.error || "The automated test did not return a result")}</td></tr>`;
      }

      return `<tr><td><strong>${escapeHtml(item.pageType)}</strong><br><span class="mono">${escapeHtml(pagePath(item.url))}</span></td><td class="score" style="color:${scoreHex(item.scores.mobile.performance)}">${item.scores.mobile.performance}</td><td class="score" style="color:${scoreHex(item.scores.mobile.seo)}">${item.scores.mobile.seo}</td><td class="score" style="color:${scoreHex(item.scores.mobile.accessibility)}">${item.scores.mobile.accessibility}</td><td class="score" style="color:${scoreHex(item.scores.mobile.bestPractices)}">${item.scores.mobile.bestPractices}</td><td class="score" style="color:${scoreHex(item.scores.desktop?.performance)}">${item.scores.desktop?.performance ?? "Not tested"}</td></tr>`;
    })
    .join("");

  const findingCards = technicalFindings.length
    ? technicalFindings
        .map(
          (finding) => `
      <article class="finding-card">
        <div class="finding-meta"><span class="severity severity-${escapeHtml(finding.priority)}">${finding.priority === "high" ? "Priority" : finding.priority === "medium" ? "Important" : "Review"}</span><span>${escapeHtml(finding.pageType)} - ${escapeHtml(finding.categoryLabel)}</span></div>
        <h3>${escapeHtml(friendlyFindingTitle(finding))}</h3>
        <p><strong>Why it matters:</strong> ${escapeHtml(findingImpact(finding))}</p>
        <p><strong>Measured evidence:</strong> ${escapeHtml(buildFindingEvidence(finding) || "See the full automated result for this page.")}</p>
        <div class="technical-name">Technical check: ${escapeHtml(finding.title)}</div>
        <div class="mono">${escapeHtml(pagePath(finding.url))}</div>
      </article>`,
        )
        .join("")
    : '<p class="muted">No detailed automated findings were available for the completed page tests.</p>';

  const pageRows = pages
    .map((page) => {
      if (page.status !== "ok") {
        return `<tr><td><strong>${escapeHtml(page.pageType)}</strong><br><span class="mono">${escapeHtml(pagePath(page.url))}</span></td><td colspan="6">Unavailable during this review: ${escapeHtml(page.error || "Request failed")}</td></tr>`;
      }

      return `<tr><td><strong>${escapeHtml(page.pageType)}</strong><br><span class="mono">${escapeHtml(pagePath(page.url))}</span></td><td>${page.title ? "Present" : "Missing"}</td><td>${page.metaDescription ? "Present" : "Missing"}</td><td>${page.h1Count}</td><td>${page.canonicalPresent ? "Confirmed" : "Review"}</td><td>${page.imagesMissingAlt}</td><td>${page.robotsNoindex ? "Hidden - confirm intent" : "Visible signal"}</td></tr>`;
    })
    .join("");

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Digital Growth and Website Review - ${escapeHtml(company)}</title>
  <style>
    *{box-sizing:border-box}html{background:#e8edf4}body{margin:0 auto;max-width:920px;background:#fff;color:#172033;font:14px/1.62 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
    .page{padding:48px 52px}.cover{min-height:1030px;display:flex;flex-direction:column;background:linear-gradient(145deg,#081426 0%,#112b4f 62%,#176b77 100%);color:#fff}.brand{font-weight:800;letter-spacing:.04em}.eyebrow{margin-top:auto;color:#72e4d7;font-size:11px;font-weight:800;letter-spacing:.18em;text-transform:uppercase}
    h1{max-width:720px;margin:18px 0 20px;font-size:46px;line-height:1.06;letter-spacing:-.035em}.cover h2{margin:0;font-size:21px;font-weight:500;color:#c6d8ea}.cover-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:56px;padding-top:24px;border-top:1px solid rgba(255,255,255,.22)}.cover-label{color:#8fb2d1;font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.cover-value{margin-top:5px;font-size:15px}.cover-foot{margin-top:auto;color:#afc7dc;font-size:12px}
    h2{margin:0 0 15px;color:#0b2748;font-size:27px;line-height:1.18;letter-spacing:-.025em}h3{margin:0 0 8px;color:#17304f;font-size:18px;line-height:1.3}.section{margin-bottom:34px}.lead{margin:0;color:#34445a;font-size:16px;line-height:1.75}.kicker{margin-bottom:7px;color:#087d79;font-size:11px;font-weight:800;letter-spacing:.15em;text-transform:uppercase;break-after:avoid}.muted{color:#69788d}.mono{overflow-wrap:anywhere;color:#52647a;font:10.5px/1.45 ui-monospace,SFMono-Regular,Consolas,monospace}
    .scope-strip{display:flex;justify-content:space-between;gap:24px;margin:24px 0;padding:16px 18px;border-left:4px solid #1ea99c;background:#effaf8;color:#315a59}.scope-strip strong{color:#0b615e}.score-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:11px}.score-card{padding:16px;border:1px solid #dce4ee;border-radius:11px;background:#f8fafc}.score-label{color:#65758a;font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase}.score-value{margin:6px 0 2px;font-size:30px;font-weight:800}.score-meaning{color:#617189;font-size:11px}
    .takeaway{margin-top:22px;padding:20px;border:1px solid #bcece6;border-radius:12px;background:#f1fbfa}.takeaway h3{font-size:19px}.clean-list{margin:0;padding:0;list-style:none}.clean-list li{position:relative;margin:0 0 10px;padding-left:17px}.clean-list li:before{position:absolute;left:0;color:#15958d;content:"•";font-weight:900}
    .priority-grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.priority-card{display:grid;grid-template-columns:34px 1fr;gap:12px;padding:18px;border:1px solid #dce4ee;border-radius:12px;break-inside:avoid}.priority-urgent{border-color:#fecdd3;background:#fff7f8}.priority-important{border-color:#fde3ad;background:#fffbf2}.priority-measure{border-color:#bcece6;background:#f2fbfa}.priority-number{display:flex;width:30px;height:30px;align-items:center;justify-content:center;border-radius:999px;background:#0d2746;color:#fff;font-weight:800}.priority-card p{margin:7px 0;color:#43536a;font-size:13px}.priority-card strong{color:#193451}
    .measurement-note{margin-top:18px;padding:16px 18px;border-radius:11px;background:#0d2746;color:#e8f2fb}.measurement-note strong{color:#fff}
    .support{padding:24px;border-radius:14px;background:#0d2746;color:#e8f2fb;break-inside:avoid}.support h2{color:#fff}.support .clean-list li:before{color:#49d7c7}.support .muted{color:#b8c9da}.next-step{margin-top:18px;padding-top:16px;border-top:1px solid rgba(255,255,255,.2)}
    .technical-intro{padding:18px 20px;border-left:4px solid #1ea99c;background:#edf3f8;color:#40536b}.tech-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.tech-item{padding:13px;border:1px solid #dce4ee;border-radius:9px;break-inside:avoid}.tech-label{color:#718096;font-size:9px;font-weight:800;letter-spacing:.1em;text-transform:uppercase}.tech-value{margin-top:5px;color:#20344f;font-size:12px;font-weight:600}
    table{width:100%;border-collapse:collapse;font-size:11px}th{padding:9px 8px;border-bottom:2px solid #bdd0e3;background:#f3f7fb;color:#456078;text-align:left;text-transform:uppercase;letter-spacing:.05em}td{padding:10px 8px;border-bottom:1px solid #e4eaf1;vertical-align:top}.score{font-size:15px;font-weight:800}.severity{display:inline-block;padding:4px 7px;border-radius:999px;font-size:9px;font-weight:800;letter-spacing:.05em;text-transform:uppercase;white-space:nowrap}.severity-high{background:#ffe8eb;color:#b4233d}.severity-medium{background:#fff2d5;color:#9a5a00}.severity-low,.severity-review{background:#e7f0fa;color:#315f8c}
    .finding-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.finding-card{padding:16px;border:1px solid #dce4ee;border-radius:11px;break-inside:avoid}.finding-meta{display:flex;align-items:center;gap:8px;margin-bottom:9px;color:#6a788b;font-size:10px;text-transform:uppercase}.finding-card p{margin:0 0 8px;color:#53647a;font-size:11.5px}.technical-name{margin:8px 0 3px;color:#7a8798;font-size:10px}.footer{display:flex;justify-content:space-between;gap:20px;margin-top:34px;padding-top:14px;border-top:1px solid #dce4ee;color:#8592a3;font-size:10px}
    h2,h3{break-after:avoid}tr,.score-card,.tech-item,.finding-card{break-inside:avoid}.after-cover{break-before:page}.page-break{break-before:page}.avoid-break{break-inside:avoid}
    @page{size:A4;margin:10mm}@media print{html{background:#fff}body{max-width:none}.page{padding:20px 24px}.cover{min-height:calc(297mm - 20mm);padding:38px 42px}a{color:inherit;text-decoration:none}.after-cover,.page-break{break-before:page}}
  </style>
</head>
<body>
  <section class="page cover">
    <div class="brand">${escapeHtml(profileValues.yourCompany)}</div>
    <div class="eyebrow">Evidence-led digital review</div>
    <h1>Digital Growth &amp;<br>Website Review</h1>
    <h2>Prepared for ${escapeHtml(company)}</h2>
    <div class="cover-grid">
      <div><div class="cover-label">Website reviewed</div><div class="cover-value">${escapeHtml(displayUrl)}</div></div>
      <div><div class="cover-label">Prepared by</div><div class="cover-value">${escapeHtml(profileValues.yourName)}<br>${escapeHtml(profileValues.yourTitle)}</div></div>
      <div><div class="cover-label">Review date</div><div class="cover-value">${escapeHtml(reportDate)}</div></div>
      <div><div class="cover-label">Review type</div><div class="cover-value">Preliminary external assessment</div></div>
      ${contactLinks.length ? `<div><div class="cover-label">Contact</div><div class="cover-value">${contactLinks.map((value) => escapeHtml(value)).join("<br>")}</div></div>` : ""}
    </div>
    <div class="cover-foot">Growth opportunities first. Detailed technical evidence follows at the end.</div>
  </section>

  <main class="page after-cover">
    <section class="section">
      <div class="kicker">Opportunity overview</div>
      <h2>Where the website could deliver even more value</h2>
      <p class="lead">${escapeHtml(clientSummary)}</p>
      <div class="scope-strip"><span><strong>${successfulPages}</strong> public pages in the reviewed sample</span><span><strong>${summary?.count ?? 0}</strong> key pages successfully tested</span><span><strong>${escapeHtml(discoveryDisplay)}</strong> public URL candidates found</span></div>
      <div class="score-grid">${scoreCards.map(([label, value, meaning]) => `<div class="score-card"><div class="score-label">${escapeHtml(label)}</div><div class="score-value" style="color:${scoreHex(typeof value === "number" ? value : null)}">${escapeHtml(value ?? "N/A")}</div><div class="score-meaning">${escapeHtml(meaning)}</div></div>`).join("")}</div>
      <div class="takeaway"><h3>The overall picture</h3>${renderList(buildOverallPicture(result), "clean-list")}</div>
    </section>

    <section class="section page-break">
      <div class="kicker">Focused opportunities</div><h2>Where improvements could add the most value</h2>
      <p class="lead">The existing website already contains valuable services, property information and enquiry options. These opportunities focus on helping that content work harder for visitors and the business.</p>
      <div class="priority-grid">${priorityCards}</div>
      <div class="measurement-note"><strong>Measurement opportunity:</strong> ${escapeHtml(analyticsSummary(result))} Confirming property views, enquiry starts, completed enquiries, telephone clicks and email actions would help guide future improvements with real visitor evidence.</div>
    </section>

    <section class="section page-break"><div class="kicker">Measured website evidence</div><h2>Highest-priority automated findings</h2><p class="muted">These checks explain the most important measured issues in plain language. The original technical names remain underneath for the team responsible for implementation.</p><div class="finding-grid">${findingCards}</div></section>

    <section class="section support">
      <div class="kicker">How I can help</div><h2>Support shaped around ${escapeHtml(company)}'s priorities</h2>
      <p class="muted">I would begin with discovery to understand the organisation, priority audiences, current systems and growth goals before confirming the right scope.</p>
      ${renderList(SERVICES, "clean-list")}
      <p class="next-step"><strong>A practical next step:</strong> review the findings together, confirm current analytics and enquiry processes, then agree on the improvements most likely to benefit visitors and the business.</p>
    </section>

    <section class="section page-break">
      <div class="kicker">Technical details</div><h2>Evidence behind the opportunity summary</h2>
      <p class="technical-intro">The following results preserve the automated and page-level evidence supporting this preliminary review. They reflect publicly accessible pages at one point in time and should be validated before implementation scope is confirmed.</p>
    </section>

    <section class="section"><div class="kicker">Website platform</div><h2>Publicly detectable technology</h2><p class="muted">These are visible public signals. They do not confirm configuration quality, data accuracy, consent compliance or internal ownership.</p><div class="tech-grid">${techGroups.map(([label, value]) => `<div class="tech-item"><div class="tech-label">${escapeHtml(label)}</div><div class="tech-value">${escapeHtml(value)}</div></div>`).join("")}</div></section>

    <section class="section avoid-break"><div class="kicker">Representative testing</div><h2>Page-level automated score comparison</h2><p class="muted">Mobile testing was attempted for ${summary?.attemptedCount ?? deepResults.length} important pages. ${summary?.count ?? 0} completed successfully${(summary?.failedCount ?? 0) > 0 ? `, while ${summary?.failedCount} did not complete and ${summary?.failedCount === 1 ? "was" : "were"} excluded from the averages` : ""}. Desktop performance is shown only where a separate desktop test completed.</p><table><thead><tr><th>Page</th><th>Mobile speed</th><th>Search</th><th>Accessibility</th><th>Best practices</th><th>Desktop speed</th></tr></thead><tbody>${deepRows || '<tr><td colspan="6">No representative results were available.</td></tr>'}</tbody></table></section>

    <section class="section page-break"><div class="kicker">Page inventory</div><h2>Page-by-page implementation checks</h2><p class="muted">This inventory helps technical teams locate recurring template patterns. “Review” means the public scan could not safely confirm the intended setup.</p><table><thead><tr><th>Page</th><th>Search title</th><th>Search summary</th><th>Main headings</th><th>Preferred address</th><th>Images to review</th><th>Search visibility</th></tr></thead><tbody>${pageRows}</tbody></table></section>

    <section class="section"><div class="kicker">Scope and interpretation</div><h2>Important limitations</h2>${renderList(list(report?.scopeNotes), "clean-list")}<p class="muted">This preliminary external review covers publicly accessible pages at one point in time. Automated checks do not replace manual accessibility testing, authenticated journey testing, stakeholder discovery, analytics review, CRM validation or source-code inspection.</p></section>

    <footer class="footer"><span>${escapeHtml(profileValues.yourCompany)} - ${escapeHtml(profileValues.yourName)}${profileValues.yourWebsite ? ` - ${escapeHtml(profileValues.yourWebsite)}` : ""}</span><span>${escapeHtml(displayUrl)} - ${escapeHtml(reportDate)}</span></footer>
  </main>
  <script>window.onload=function(){setTimeout(function(){window.print()},500)}</script>
</body>
</html>`;
}

function exportReport(
  result: FullSiteAuditResult,
  profile?: Partial<UserProfile>,
) {
  const html = buildReportHtml(result, profile);
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const printUrl = URL.createObjectURL(blob);
  window.open(printUrl, "_blank", "noopener,noreferrer");
  window.setTimeout(() => URL.revokeObjectURL(printUrl), 60_000);
}

function BulletList({ items }: { items: string[] }) {
  if (!items.length) {
    return (
      <p className="text-sm text-muted-foreground">No item was generated.</p>
    );
  }

  return (
    <ul className="space-y-2">
      {items.map((item) => (
        <li
          key={item}
          className="flex items-start gap-3 text-sm leading-relaxed text-secondary-foreground"
        >
          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-teal-400" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

export default function FullSiteAuditReport({ result, profile }: Props) {
  const report = result.siteReport;
  const pages = list(result.lightweightResults);
  const successfulPages = pages.filter((page) => page.status === "ok").length;

  if (!result.success || !report) return null;

  const priorities = buildClientPriorities(result, successfulPages);
  const metrics = [
    ["Pages reviewed", successfulPages],
    ["Key pages tested", result.deepSummary?.count ?? 0],
    ["Mobile speed", result.deepSummary?.averageMobilePerformance ?? "N/A"],
    ["Search readiness", result.deepSummary?.averageSeo ?? "N/A"],
    ["Accessibility", result.deepSummary?.averageAccessibility ?? "N/A"],
  ];

  return (
    <section className="space-y-6">
      <div className="overflow-hidden rounded-[28px] border border-teal-500/20 bg-gradient-to-br from-card via-teal-500/[0.04] to-card">
        <div className="flex flex-col gap-5 border-b border-border p-6 sm:flex-row sm:items-start sm:justify-between sm:p-8">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-teal-300">
              JM Sites client report
            </p>
            <h2 className="mt-2 text-2xl font-bold tracking-tight text-foreground">
              Digital Growth &amp; Website Review
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Prepared for {clientName(result)}
            </p>
          </div>
          <button
            type="button"
            onClick={() => exportReport(result, profile)}
            className="inline-flex items-center justify-center rounded-xl bg-teal-600 px-5 py-3 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-teal-500"
          >
            Download client PDF
          </button>
        </div>

        <div className="grid gap-3 p-6 sm:grid-cols-3 sm:p-8 lg:grid-cols-5">
          {metrics.map(([label, value]) => (
            <div
              key={String(label)}
              className="rounded-2xl border border-border bg-secondary/25 p-4"
            >
              <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                {label}
              </p>
              <p
                className="mt-2 text-2xl font-bold"
                style={{
                  color:
                    typeof value === "number" &&
                    !String(label).includes("Pages")
                      ? scoreHex(value)
                      : undefined,
                }}
              >
                {value}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card p-6">
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-teal-300">
          Opportunity overview
        </p>
        <h3 className="mt-2 text-lg font-semibold text-foreground">
          Where the website could deliver even more value
        </h3>
        <p className="mt-3 text-sm leading-7 text-secondary-foreground">
          {buildClientSummary(result, successfulPages)}
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {priorities.map((priority, index) => (
          <div
            key={priority.title}
            className="rounded-2xl border border-border bg-card p-6"
          >
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-teal-300">
              Opportunity {index + 1}
            </p>
            <h3 className="mt-2 text-base font-semibold text-foreground">
              {priority.title}
            </h3>
            <p className="mt-3 text-sm text-secondary-foreground">
              <strong>What we found:</strong> {priority.finding}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              <strong className="text-secondary-foreground">
                Why it matters:
              </strong>{" "}
              {priority.impact}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              <strong className="text-secondary-foreground">What to do:</strong>{" "}
              {priority.action}
            </p>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-teal-500/20 bg-teal-500/[0.04] p-6">
        <h3 className="text-base font-semibold text-foreground">
          Measurement opportunity
        </h3>
        <p className="mt-3 text-sm leading-7 text-secondary-foreground">
          {analyticsSummary(result)} Confirming property views, enquiry starts,
          completed enquiries, telephone clicks and email actions would help
          guide future improvements with real visitor evidence.
        </p>
      </div>

      <div className="rounded-2xl border border-blue-500/20 bg-blue-500/[0.04] p-6">
        <h3 className="text-base font-semibold text-foreground">
          Scope and interpretation
        </h3>
        <div className="mt-4">
          <BulletList items={report.scopeNotes} />
        </div>
      </div>
    </section>
  );
}
